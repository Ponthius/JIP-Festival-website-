document.addEventListener('DOMContentLoaded', function () {
    const form = document.getElementById('votingForm');

    // Check if the user has already voted
    if (getCookie('hasVoted')) {
        alert('You have already voted. You can vote again after 24 hours.');
        form.classList.add('hidden');
        return;
    }

    form.addEventListener('submit', function (event) {
        event.preventDefault();

        const formData = new FormData(form);
        const xhr = new XMLHttpRequest();
        xhr.open('POST', form.action, true);

        xhr.onload = function () {
            if (xhr.status === 200) {
                alert('Thank you for voting!');
                setCookie('hasVoted', 'true', 1); // Set the cookie to expire in 1 day
                form.reset();
                form.classList.add('hidden');
            } else {
                alert('There was an error submitting your vote. Please try again.');
            }
        };

        xhr.send(formData);
    });

    function setCookie(name, value, days) {
        const d = new Date();
        d.setTime(d.getTime() + (days * 24 * 60 * 60 * 1000));
        const expires = "expires=" + d.toUTCString();
        document.cookie = name + "=" + value + ";" + expires + ";path=/";
    }

    function getCookie(name) {
        const decodedCookie = decodeURIComponent(document.cookie);
        const ca = decodedCookie.split(';');
        name = name + "=";
        for (let i = 0; i < ca.length; i++) {
            let c = ca[i];
            while (c.charAt(0) === ' ') {
                c = c.substring(1);
            }
            if (c.indexOf(name) === 0) {
                return c.substring(name.length, c.length);
            }
        }
        return "";
    }
});