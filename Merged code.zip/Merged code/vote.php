<?php
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $to = 'jinjainternationalpoetryfest@gmail.com'; // Update recipient email
    $subject = 'New Vote Submission';
    $message = '';

    foreach ($_POST as $category => $vote) {
        $message .= "$category: $vote\n";
    }

    $headers = 'From: webmaster@example.com' . "\r\n" .
               'Reply-To: webmaster@example.com' . "\r\n" .
               'X-Mailer: PHP/' . phpversion();

    if (mail($to, $subject, $message, $headers)) {
        http_response_code(200);
        echo 'Vote submitted successfully';
    } else {
        http_response_code(500);
        echo 'Error submitting vote';
    }
} else {
    http_response_code(405);
    echo 'Method not allowed';
}
?>