document.addEventListener('DOMContentLoaded', function() {
    const voteButtons = document.querySelectorAll('.vote-btn');
    const submitVotesButton = document.getElementById('submitVotes');
    const form = document.getElementById('voteForm');

    // Helper function to get category name from the card container
    function getCategory(button) {
        return button.closest('[data-category]').getAttribute('data-category');
    }

    // Helper function to save vote to localStorage
    function saveVote(category, voteId) {
        const votes = JSON.parse(localStorage.getItem('votes')) || {};
        votes[category] = voteId;
        localStorage.setItem('votes', JSON.stringify(votes));
    }

    // Helper function to check if a vote already exists
    function hasVotedToday() {
        const lastVoteTime = localStorage.getItem('lastVoteTime');
        const now = new Date().getTime();
        const oneDay = 24 * 60 * 60 * 1000; // One day in milliseconds
        return lastVoteTime && (now - lastVoteTime) < oneDay;
    }

    // Helper function to load saved votes
    function loadVotes() {
        const votes = JSON.parse(localStorage.getItem('votes')) || {};
        for (const [category, voteId] of Object.entries(votes)) {
            const input = document.getElementById(category.replace(/ /g, ''));

            if (input) {
                input.value = voteId;
            }
        }
    }

    voteButtons.forEach(button => {
        button.addEventListener('click', function() {
            if (hasVotedToday()) {
                alert('You can only vote once per day. Please try again tomorrow.');
                return;
            }

            const category = getCategory(this);
            const voteId = this.getAttribute('data-vote-id');

            // Save the vote in localStorage
            saveVote(category, voteId);

            // Set the corresponding hidden input value
            const input = document.getElementById(category.replace(/ /g, ''));
            if (input) {
                input.value = voteId;
            }

            alert(`Vote recorded for ${category}: ${voteId}`);
        });
    });

    submitVotesButton.addEventListener('click', function() {
        if (hasVotedToday()) {
            alert('You can only vote once per day. Please try again tomorrow.');
            return;
        }

        // Save the current vote time
        localStorage.setItem('lastVoteTime', new Date().getTime());

        // Submit the form
        form.submit();
    });

    // Load votes from localStorage on page load
    loadVotes();
});
