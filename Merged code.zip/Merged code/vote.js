document.addEventListener('DOMContentLoaded', function() {
    const voteButtons = document.querySelectorAll('.vote-btn');

    voteButtons.forEach(button => {
        button.addEventListener('click', function() {
            const voteId = this.getAttribute('data-vote-id');

            // Check if the user has already voted today
            const lastVoteTime = localStorage.getItem('lastVoteTime');
            const now = new Date().getTime();
            const oneDay = 24 * 60 * 60 * 1000; // One day in milliseconds

            if (lastVoteTime && (now - lastVoteTime) < oneDay) {
                alert('You can only vote once per day. Please try again tomorrow.');
                return;
            }

            // Save the vote time
            localStorage.setItem('lastVoteTime', now);

            // Set the hidden input value and submit the form
            const poetInput = document.getElementById('poetInput');
            poetInput.value = voteId;

            const voteForm = document.getElementById('voteForm');
            voteForm.submit();

            alert('Thank you for your vote!');
        });
    });
});
